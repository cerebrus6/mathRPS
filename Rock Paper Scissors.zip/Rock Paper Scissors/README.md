# mathRPS
Win rock paper scissors using Mathematics
